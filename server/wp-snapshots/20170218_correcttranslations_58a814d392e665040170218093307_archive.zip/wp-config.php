<?php
/**
 * The base configurations of the WordPress.
 *
 * This file has the following configurations: MySQL settings, Table Prefix,
 * Secret Keys, WordPress Language, and ABSPATH. You can find more information
 * by visiting {@link http://codex.wordpress.org/Editing_wp-config.php Editing
 * wp-config.php} Codex page. You can get the MySQL settings from your web host.
 *
 * This file is used by the wp-config.php creation script during the
 * installation. You don't have to use the web site, you can just copy this file
 * to "wp-config.php" and fill in the values.
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'ct_ee');

/** MySQL database username */
define('DB_USER', 'ct_ee');

/** MySQL database password */
define('DB_PASSWORD', 'Aid3eesh');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '% 94^Zqj.`)-Aao|hO3>P0XZZ,iQWh~e qO&q-s=tw+^Ii6RyK=VX%2|wVcWBK4K');
define('SECURE_AUTH_KEY',  'Kl!K)#gD)LnRIDq61u%WwQ$k:8&F-x,9pq8*3w|b oZv6Sj^?#ctO*U!TDdbNXeP');
define('LOGGED_IN_KEY',    'Fn|.__jg%_<Utm=H9lGz,7&V0Cg~|)0ssvY=BL/QYL&{g3,uVzp(`_=XjnWl5zJ{');
define('NONCE_KEY',        '+:s=v~htHm}va[Hap-bJ3&n~r,HeFe]]~B<|O]UE&uDUV nLt||n5o^3{;)p9;_8');
define('AUTH_SALT',        'fL[neBBP2BN?!-+ES`Z7KesO{#5QPNU:G<H0~jbIlk?cR`5VpGb-tS};Iy5cyu4b');
define('SECURE_AUTH_SALT', 'LW6:er`4iiZF8c8*rxq}}C?#Rxs[|Kxf@u?joLaU_{cH`3m%#LLS$x9!(LQ 8Cm ');
define('LOGGED_IN_SALT',   '6TZ!<ed`<RReeD70q/tIVi(aLz;W!^SMp|j(j6YYOPI8:.iA=)=Yb-k9:brSjO(G');
define('NONCE_SALT',       'w8f%w}+P f)Rp#FA=2+U]4DtN @Xl^B;rAL%$_=u}M}Nb>dI=x[uX@L%NaJed[hH');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each a unique
 * prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'ct_';

/**
 * WordPress Localized Language, defaults to English.
 *
 * Change this to localize WordPress. A corresponding MO file for the chosen
 * language must be installed to wp-content/languages. For example, install
 * de_DE.mo to wp-content/languages and set WPLANG to 'de_DE' to enable German
 * language support.
 */
define('WPLANG', 'et');

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 */
define('WP_DEBUG', false);

/* Multisite */
define( 'WP_ALLOW_MULTISITE', true );

define('MULTISITE', true);
define('SUBDOMAIN_INSTALL', false);
define('DOMAIN_CURRENT_SITE', 'www.ct.ee');
define('PATH_CURRENT_SITE', '/');
define('SITE_ID_CURRENT_SITE', 1);
define('BLOG_ID_CURRENT_SITE', 1);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
